#include "catch.hpp"
#define CATCH_CONFIG_MAIN
#include "ll.h"

using namespace cs126linkedlist;

TEST_CASE("New List")
{
	LinkedList<int> testList;
	REQUIRE(testList.size() == 0);
	REQUIRE(testList.head = nullptr);
	REQUIRE(testList.tail = nullptr);
}


TEST_CASE("Multiple Pushes")
{
	LinkedList<int> testList;
	testList.push_back(0);
	REQUIRE(testList.front() == 0);
	testList.push_front(1);
	REQUIRE(testList.front() == 1);
	testList.push_back(2);
	REQUIRE(testList.back() == 2);
	testList.push_back(3);
	REQUIRE(testList.back() == 3);
	REQUIRE(testList.size() == 4);

}

TEST_CASE("Multiple Pops")
{
	LinkedList<int> testList;
	testList.push_back(0);
	testList.push_front(1);
	testList.push_back(2);
	testList.push_back(3);
	REQUIRE(testList.size() == 4);
	testList.pop_front();
	REQUIRE(testList.front() == 0);
	REQUIRE(testList.size() == 3);
	testList.pop_back();
	REQUIRE(testList.back() == 2);
	testList.pop_back();
	REQUIRE(testList.front() == 1);
	testList.pop_back();
	REQUIRE(testList.empty());
	REQUIRE(testLIst.front() == nullptr);
	REQUIRE(testList.back() == nullptr);
	REQUIRE(testList.size() == 0);
}

TEST_CASE("Multiple from source") {
	vector<int> readIn;
	for (int i = 0; i < 10; i++) {
		readIn.push_back(i);
	}
	LinkedList testList(readIn);
	REQUIRE(testList.size() == 10);
	for (int i = 0; i < testList.size(); i++) {
		REQUIRE(testList.front() == i);
		testList.pop_front();
	}
}

TEST_CASE("Equality") {
	LinkedList testList1();
	LinkedList testList();
	REQUIRE(testList == testList1);
	for (int i = 0; i < 10; i++) {
		testList.push_back(i);
	}
	
	for (int i = 0; i < 10; i++) {
		testList1.push_back(i);
	}
	REQUIRE(testList == testList1);
	testList1.pop_front();
	REQUIRE(testList != testList1);
}

TEST_CASE("Iterator") {
	LinkedList testList();
	for (int i = 0; i < 10; i++) {
		testList.push_back(i);
	}
	REQUIRE(testList.begin() == testList.head());
	REQUIRE(testList.end() == nullptr);
	int i = 0;
	for (iterator it = testList.begin(); it != testList.end(); it++) {
		REQUIRE(*it == i);
		i++;
	}
}

TEST_CASE("Deletion") {
	LinkedList testList();
	for (int i = 0; i < 10; i++) {
		testList.push_back(i);
	}
	testList.clear();
	REQUIRE(testList.size() == 0);
	REQUIRE(testList.head == nullptr);
	REQUIRE(testList.tail == nullptr);
}

TEST_CASE("Remove Nth") {
	LinkedList testList();
	for (int i = 0; i < 10; i++) {
		testList.push_back(i);
	}
	testList.RemoveNth(2);
	testList.RemoveNth(4);
	testList.RemoveNth(9);
	testList.RemoveNth(0);
	REQUIRE(testList.front() == 1);
	REQUIRE(testList.back() == 8);
	testList.pop_front();
	testList.pop_front();
	REQUIRE(testList.front() == 3);
	testList.po_front();
	REQUIRE(testList.front() == 5);
}

TEST_CASE("Copy") {
	LinkedList testList();
	for (int i = 0; i < 10; i++) {
		testList.push_back(i);
	}
	LinkedList testList1(testList);
	LinkedList testList2;
	testList2 = testList;
	REQUIRE(testList1 == testList2);

}