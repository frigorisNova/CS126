# LinkedList
Linked list build as templated code.
