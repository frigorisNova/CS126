// You can add any helper functions or headers that you need.
// You should also fill in all the function bodies.

template<typename ElementType>
LinkedList<ElementType>::LinkedList() : head_(nullptr), tail_(nullptr), size_(0) {

}

template<typename ElementType>
LinkedList<ElementType>::LinkedList(const std::vector<ElementType> &values) : head_(nullptr), tail_(nullptr), size_(0) {

	if (!values.empty()) {
		ListNode* current = new ListNode(values.at(0));
		head = current;
	}
	for (int i = 1; i < values.size(); i++) {
		ListNode* temp = new ListNode(values.at(i));
		temp->prev = current;
		current->next = temp;
		current = current->next;
	}
	tail = current;
	size = values.size();
}

// Copy constructor
template<typename ElementType>
LinkedList<ElementType>::LinkedList(const LinkedList<ElementType>& source) {
	destroy();
	ListNode * current = source->head;
	ListNode * oCurrent = current;
	while (oCurrent != nullptr) {
		ListNode* temp = new ListNode(oCurrent->value);
		current->next = temp;
		current = current->next;
		oCurrent = oCurrent->next;

	}
}

// Move constructor
template<typename ElementType>
LinkedList<ElementType>::LinkedList(LinkedList<ElementType>&& source) noexcept {
	this->head = source->head;
	this->tail = source->tail;
	source->head = nullptr;
	source->tail = nullptr;
}

// Destructor
template<typename ElementType>
LinkedList<ElementType>::~LinkedList() {
	destroy();
}

template<typename ElementType> void
LinkedList<ElementType>::destroy() {
	ListNode * current = head;
	ListNode* temp;
	while (current != nullptr) {
		temp = current;
		current = current->next;
		delete temp;
	}
	head = nullptr;
	tail = nullptr;
	size = 0;
}


// Copy assignment operator
template<typename ElementType>
LinkedList<ElementType>& LinkedList<ElementType>::operator= (const LinkedList<ElementType>& source) {
	destroy();
	ListNode * current = source->head;
	ListNode * oCurrent = current;
	while (oCurrent != nullptr) {
		ListNode* temp = new ListNode(oCurrent->value);
		current->next = temp;
		current = current->next;
		oCurrent = oCurrent->next;

	}

}

// Move assignment operator
template<typename ElementType>
LinkedList<ElementType>& LinkedList<ElementType>::operator= (LinkedList<ElementType>&& source) noexcept {
	destroy();
	this->head = source->head;
	this->tail = source->tail;
	source->head = nullptr;
	source->tail = nullptr;
}

template<typename ElementType>
void LinkedList<ElementType>::push_front(ElementType value) {
	ListNode * temp = new ListNode();
	temp.value = value;
	if (head == nullptr) {
		head = temp;
		tail = temp;
	}
	else {
		temp->next = head;
		head->prev = temp;
		head = temp;
	}
	size++;
}

template<typename ElementType>
void LinkedList<ElementType>::push_back(ElementType value) {
	ListNode * temp = new ListNode();
	temp.value = value;
	if (head == nullptr) {
		head = temp;
		tail = temp;
	}
	else {
		tail->next = temp;
		temp->prev = tail;
		tail = temp;
	}
	size++;
}

template<typename ElementType>
ElementType LinkedList<ElementType>::front() const{
	return head->value;
}

template<typename ElementType>
ElementType LinkedList<ElementType>::back() const {
	return tail->value;
}

template<typename ElementType>
void LinkedList<ElementType>::pop_front() {
	if (size == 0) {
		return;
	}
	if (head == tail) {
		delete head;
		head = nullptr;
		tail = nullptr;
	}
	else {
		temp = head;
		head = head->next;
		head->prev = nullptr;
		delete temp;
	}
	size--;
}

template<typename ElementType>
void LinkedList<ElementType>::pop_back() {
	if (size == 0) {
		return;
	}
	if (head == tail) {
		delete head;
		head = nullptr;
		tail = nullptr;
	}
	else {
		temp = tail;
		tail - tail->prev;
		tail->next = nullptr;
		delete temp;
	}
	size--;
}

template<typename ElementType>
int LinkedList<ElementType>::size() const {
	return size;
}

template<typename ElementType>
bool LinkedList<ElementType>::empty() const {
	if (head != nullptr) {
		return false;
	}
	return true;
}

template<typename ElementType>
void LinkedList<ElementType>::clear() {
	destroy();
}

template<typename ElementType>
std::ostream& operator<<(std::ostream& os, const LinkedList<ElementType>& list) {
	ListNode* current = head;
	while (current != nullptr) {
		os << current->value;
		if (current != tail) {
			os << ",";
		}
		os << " ";
		current = current->next;
	}
	return os;
}

template<typename ElementType>
void LinkedList<ElementType>::RemoveNth(int n) {
	if (n == 0) {
		pop_front();
		return;
	}
	if (n-1 == size) {
		pop_back();
		return;
	}
	ListNode* current = head;
	for (int i = 0; i < n; i++) {
		current = current->next;
	}
	ListNode temp = current->prev;
	ListNode temp2 = current->next;
	delete current;
	temp->next = temp2;
	temp2->prev = temp;
	size--;
}

template<typename ElementType>
bool LinkedList<ElementType>::operator==(const LinkedList<ElementType> &rhs) const {
	ListNode * current1 = head;
	ListNode* current2 = other->head;

	if (this->empty() && other->empty()) {
		return true;
	}
	else {
		if (this->empty()) {
			return false;
		}
		if (other->empty()) {
			return false;
		}
		while (current1 != nullptr || current2 != nullptr) {
			if (current1->value != current2->value) {
				return false;
			}
		}
		if (this->size != other->size) {
			return false;
		}
	}
	return true;
}

template<typename ElementType>
bool operator!=(const LinkedList<ElementType>& lhs, const LinkedList<ElementType> &rhs) {
	ListNode * current1 = lhs->head;
	ListNode* current2 = rhs->head;

	if (lhs->empty() && rhs->empty()) {
		return false;
	}
	else {
		if (lhs->empty()) {
			return true;
		}
		if (rhs->empty()) {
			return true;
		}
		while (current1 != nullptr || current2 != nullptr) {
			if (current1->value != current2->value) {
				return true;
			}
		}
		if (lhs->size != rhs->size) {
			return true;
		}
	}
	return false;
}

template<typename ElementType>
typename LinkedList<ElementType>::iterator& LinkedList<ElementType>::iterator::operator++() {
	current = current->next;
}

template<typename ElementType>
ElementType& LinkedList<ElementType>::iterator::operator*() {
	return current->value;
}

template<typename ElementType>
bool LinkedList<ElementType>::iterator::operator!=(const LinkedList<ElementType>::iterator& other) {
	bool empty1 = false;
	bool empty2 = false;
	empty1 = this->empty();
	empt2 = other->empty();
	if (empty == empty2) {
		if (empty1) {
			return false;
		}
		else {
			if (current == other->current) {
				return false;
			}
			return true;
		}
	}
	else {
		return true;
	}

	return true;
}

template<typename ElementType>
typename LinkedList<ElementType>::iterator LinkedList<ElementType>::begin() {
	return iterator(head);
}

template<typename ElementType>
typename LinkedList<ElementType>::iterator LinkedList<ElementType>::end() {
	return iterator(nullptr);
}

template<typename ElementType>
typename LinkedList<ElementType>::const_iterator& LinkedList<ElementType>::const_iterator::operator++() {
	current = current->next;
}

template<typename ElementType>
const ElementType& LinkedList<ElementType>::const_iterator::operator*() {
	return current->value;
}

template<typename ElementType>
bool LinkedList<ElementType>::const_iterator::operator!=(const LinkedList<ElementType>::const_iterator& other) {
	bool empty1 = false;
	bool empty2 = false;
	empty1 = this->empty();
	empt2 = other->empty();
	if (empty == empty2) {
		if (empty1) {
			return false;
		}
		else {
			if (current == other->current) {
				return false;
			}
			return true;
		}
	}
	else {
		return true;
	}
}

template<typename ElementType>
typename LinkedList<ElementType>::const_iterator LinkedList<ElementType>::begin() const {
	return iterator(head);
}

template<typename ElementType>
typename LinkedList<ElementType>::const_iterator LinkedList<ElementType>::end() const {
	return iterator(nullptr);
}
