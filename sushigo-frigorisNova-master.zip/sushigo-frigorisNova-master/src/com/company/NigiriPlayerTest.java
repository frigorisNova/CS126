package com.company;

import com.company.CardType;
import com.company.Player;
import com.company.players.RandomPlayer;
import com.company.players.competition.NigiriPlayer;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class NigiriPlayerTest {

    private List<CardType> hand = new ArrayList();
    Player testPlayer = new NigiriPlayer();
    @Before
    public void setUp(){
        List<String> playerList = new ArrayList<>();
        playerList.add(testPlayer.getName());
        testPlayer.init("I hate everything", playerList);
    }

    @Test
    public void getName() throws Exception{
        assertEquals(testPlayer.getName(), "I hate everything");
    }

    @Test
    public void testNoOptionHand() throws Exception{
        List<CardType> expectedResult = new ArrayList();
        hand.add(CardType.Tempura);
        testPlayer.receiveHand(hand);
        expectedResult.add(CardType.Tempura);
        assertEquals(expectedResult, testPlayer.giveCardsPlayed());
    }

    @Test
    public void testPudding() throws Exception{
        hand.add(CardType.Pudding);
        List<CardType> expectedResult = new ArrayList();
        testPlayer.receiveHand(hand);
        expectedResult.add(CardType.Pudding);
        assertEquals(expectedResult, testPlayer.giveCardsPlayed());
    }

    @Test public void testDumpling(){
        hand.add(CardType.Dumpling);
        List<CardType> expectedResult = new ArrayList();
        testPlayer.receiveHand(hand);
        expectedResult.add(CardType.Dumpling);
        assertEquals(expectedResult, testPlayer.giveCardsPlayed());


    }

    @Test
    public void testNigiris(){
        hand.add(CardType.SquidNigiri);
        List<CardType> expectedResult = new ArrayList();
        testPlayer.receiveHand(hand);
        expectedResult.add(CardType.SquidNigiri);
        assertEquals(expectedResult, testPlayer.giveCardsPlayed());

    }

    @Test
    public void testWasabi(){
        hand.add(CardType.Wasabi);
        List<CardType> expectedResult = new ArrayList();
        testPlayer.receiveHand(hand);
        expectedResult.add(CardType.Wasabi);
        assertEquals(expectedResult, testPlayer.giveCardsPlayed());
    }

}