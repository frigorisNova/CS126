package com.company.players.competition;

import com.company.CardType;
import com.company.Player;
import com.company.TurnResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class NigiriPlayer implements Player {
    private List<String> playerList;

    private List<CardType> hand;
    private String name_;
    private int score_;
    private List<CardType> returnHand;

    public void init(String name, List<String> allNames) {
        name_ = name;
        playerList = allNames;
        hand = new ArrayList<CardType>();
        returnHand = new ArrayList<CardType>();
    }

    public void newGame() {
        score_ = 0;
    }

    public void receiveHand(List<CardType> cards) {
        returnHand.clear();
        hand = cards;

    }

    public List<CardType> giveCardsPlayed() {
        if (hand.contains(CardType.Wasabi)){
            returnHand.add(CardType.Wasabi);
            return returnHand;
        }
        if (hand.contains(CardType.SquidNigiri)){
            returnHand.add(CardType.SquidNigiri);
            return returnHand;
        }
        if (hand.contains(CardType.SalmonNigiri)){
            returnHand.add(CardType.SalmonNigiri);
            return returnHand;
        }
        if (hand.contains(CardType.EggNigiri)){
            returnHand.add(CardType.EggNigiri);
            return returnHand;
        }
        if (hand.contains(CardType.Dumpling)){
            returnHand.add(CardType.Dumpling);
            return returnHand;
        }
        if (hand.contains(CardType.Pudding)){
            returnHand.add(CardType.Pudding);
            return returnHand;
        }
        returnHand.add(hand.get(0));
        return returnHand;
    }

    public void endRound(Map<String, Integer> pointmap) {
        score_ = score_ + pointmap.get(name_);
    }

    public void receiveTurnResults(List<TurnResult> turnResults) {

    }

    public void endGame(Map<String, Integer> pointMap) {

    }

    public String getName() {
        return "I hate everything";
    }


}
