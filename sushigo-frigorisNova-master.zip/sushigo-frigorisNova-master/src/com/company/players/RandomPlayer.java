package com.company.players;

import com.company.CardType;
import com.company.Player;
import com.company.TurnResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class RandomPlayer implements Player {

    private List<CardType> hand;
    private List<String> playerList;
    private String name_;
    private int score_;
    private List<CardType> returnHand;

    public void init(String name, List<String> allNames) {
        name_ = name;
        playerList = allNames;
        hand = new ArrayList<CardType>();
        returnHand = new ArrayList<CardType>();
    }

    public void newGame() {
        score_ = 0;
    }

    public void receiveHand(List<CardType> cards) {
        returnHand.clear();
        hand = cards;

    }

    public List<CardType> giveCardsPlayed() {

        returnHand.add(hand.get(0));
        return returnHand;
    }

    public void endRound(Map<String, Integer> pointmap) {
        score_ = score_ + pointmap.get(name_);
    }

    public void receiveTurnResults(List<TurnResult> turnResults) {

    }

    public void endGame(Map<String, Integer> pointMap) {

    }

    public String getName() {
        return name_;
    }


}
