package com.company;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class GameEngine {

    private boolean isPlaying;
    private List<Player> currentPlayers;
    private ArrayList<CardType> deck_;
    private ArrayList<List<CardType>> currentHands;
    private Map<String, Integer> scoreBoard;
    private List<CardType> table1;
    private List<CardType> table2;
    private List<CardType> table3;
    private List<CardType> table4;
    private ArrayList<List<CardType>> tables;
    private List<Integer> pudding_;
    private ArrayList<Integer> scores;
    private ArrayList<String> names;
    private List<TurnResult> turnResults;
    private ArrayList<Integer> winner;
    static final int TOTAL_PLAYERS = 4;
    static final int STARTING_HAND = 8;

    public GameEngine(List<Player> playerList) {
        currentPlayers = playerList;

        names = new ArrayList<String>();
        names.add("Alex");
        names.add("Ben");
        names.add("Carl");
        names.add("Jason");
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            names.set(i, names.get(i) + Integer.toString(i + 1));
        }
        winner = new ArrayList<Integer>();


    }

    public void startGame() {
        scoreBoard = new HashMap<String, Integer>();
        initPlayers();
        tables = new ArrayList<List<CardType>>();
        currentHands = new ArrayList<List<CardType>>();
        table1 = new ArrayList<CardType>();
        table2 = new ArrayList<CardType>();
        table3 = new ArrayList<CardType>();
        table4 = new ArrayList<CardType>();
        tables.add(table1);
        tables.add(table2);
        tables.add(table3);
        tables.add(table4);
        deck_ = new ArrayList<CardType>();
        pudding_ = new ArrayList<Integer>();
        scores = new ArrayList<Integer>();
        int w1 = 0;
        int w2 = 0;
        int w3 = 0;
        int w4 = 0;
        winner.add(w1);
        winner.add(w2);
        winner.add(w3);
        winner.add(w4);
        int p1 = 0;
        int p2 = 0;
        int p3 = 0;
        int p4 = 0;
        pudding_.add(p1);
        pudding_.add(p2);
        pudding_.add(p3);
        pudding_.add(p4);
        initDeck();
        for (int i = 0; i < currentPlayers.size(); i++) {
            currentPlayers.get(i).newGame();
        }


    }

    public void initDeck() {
        for (int i = 0; i < 14; i++) {
            deck_.add(CardType.Tempura);
        }

        for (int i = 0; i < 14; i++) {
            deck_.add(CardType.Sashimi);
        }
        for (int i = 0; i < 14; i++) {
            deck_.add(CardType.Dumpling);
        }
        for (int i = 0; i < 12; i++) {
            deck_.add(CardType.MakiRollTwo);
        }
        for (int i = 0; i < 8; i++) {
            deck_.add(CardType.MakiRollThree);
        }
        for (int i = 0; i < 6; i++) {
            deck_.add(CardType.MakiRollOne);
        }
        for (int i = 0; i < 10; i++) {
            deck_.add(CardType.SalmonNigiri);
        }
        for (int i = 0; i < 5; i++) {
            deck_.add(CardType.SquidNigiri);
        }
        for (int i = 0; i < 5; i++) {
            deck_.add(CardType.EggNigiri);
        }
        for (int i = 0; i < 10; i++) {
            deck_.add(CardType.Pudding);
        }
        for (int i = 0; i < 6; i++) {
            deck_.add(CardType.Wasabi);
        }
        for (int i = 0; i < 4; i++) {
            deck_.add(CardType.Chopsticks);
        }


    }

    public void initPlayers() {

        currentPlayers.get(0).init(names.get(0), names);
        currentPlayers.get(1).init(names.get(1), names);
        currentPlayers.get(2).init(names.get(2), names);
        currentPlayers.get(3).init(names.get(3), names);

        scoreBoard.put(currentPlayers.get(0).getName(), 0);
        scoreBoard.put(currentPlayers.get(1).getName(), 0);
        scoreBoard.put(currentPlayers.get(2).getName(), 0);
        scoreBoard.put(currentPlayers.get(3).getName(), 0);

    }

    public void printWins() {
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            System.out.print(currentPlayers.get(i).getName() + ": ");
            System.out.print(winner.get(i) + "\n");
        }
    }

    public ArrayList<CardType> drawHand() {
        ArrayList<CardType> hand = new ArrayList<CardType>();
        for (int i = 0; i < STARTING_HAND; i++) {
            hand.add(deck_.get(randomNumber()));
            deck_.remove(hand.get(hand.size() - 1));
        }
        currentHands.add(hand);
        return hand;

    }

    //rewrite numbers
    public void passHand(int roundNumber, int turn) {

        if (roundNumber % 2 == 0) {
            currentHands.get((3 * turn) % TOTAL_PLAYERS).remove(tables.get(0).get(turn));
            currentHands.get((1 + 3 * turn) % TOTAL_PLAYERS).remove(tables.get(1).get(turn));
            currentHands.get((2 + 3 * turn) % TOTAL_PLAYERS).remove(tables.get(2).get(turn));
            currentHands.get((3 + 3 * turn) % TOTAL_PLAYERS).remove(tables.get(3).get(turn));
            currentPlayers.get(0).receiveHand(currentHands.get((3 + 3 * turn) % TOTAL_PLAYERS));
            currentPlayers.get(1).receiveHand(currentHands.get((3 * turn) % TOTAL_PLAYERS));
            currentPlayers.get(2).receiveHand(currentHands.get((1 + 3 * turn) % TOTAL_PLAYERS));
            currentPlayers.get(3).receiveHand(currentHands.get((2 + 3 * turn) % TOTAL_PLAYERS));
        } else {
            currentHands.get(turn % TOTAL_PLAYERS).remove(tables.get(0).get(turn));
            currentHands.get((1 + turn) % TOTAL_PLAYERS).remove(tables.get(1).get(turn));
            currentHands.get((2 + turn) % TOTAL_PLAYERS).remove(tables.get(2).get(turn));
            currentHands.get((3 + turn) % TOTAL_PLAYERS).remove(tables.get(3).get(turn));
            currentPlayers.get(0).receiveHand(currentHands.get((1 + turn) % TOTAL_PLAYERS));
            currentPlayers.get(1).receiveHand(currentHands.get((2 + turn) % TOTAL_PLAYERS));
            currentPlayers.get(2).receiveHand(currentHands.get((3 + turn) % TOTAL_PLAYERS));
            currentPlayers.get(3).receiveHand(currentHands.get((0 + turn) % TOTAL_PLAYERS));

        }
    }

    public int randomNumber() {
        int random = deck_.size();
        random = ThreadLocalRandom.current().nextInt(1, random);
        return random;
    }

    public void calculateScore() {
        //Note: after each check pop the card
        //Keep an array of the scores mapped to player 1,2,3,4 on array[] then add by string to hash
        //check for makis
        ArrayList<Integer> maki = new ArrayList<Integer>();
        int p1 = 0;
        int p2 = 0;
        int p3 = 0;
        int p4 = 0;

        scores.add(p1);
        scores.add(p2);
        scores.add(p3);
        scores.add(p4);
        maki.add(0);
        maki.add(0);
        maki.add(0);
        maki.add(0);
        for (int i = 0; i < TOTAL_PLAYERS; i++) {

            while (tables.get(i).contains(CardType.MakiRollThree)) {
                maki.set(i, maki.get(i) + 3);
                tables.get(i).remove(CardType.MakiRollThree);

            }
            while (tables.get(i).contains(CardType.MakiRollTwo)) {
                maki.set(i, maki.get(i) + 2);
                tables.get(i).remove(CardType.MakiRollTwo);

            }
            while (tables.get(i).contains(CardType.MakiRollOne)) {
                maki.set(i, maki.get(i) + 1);
                tables.get(i).remove(CardType.MakiRollOne);
            }
        }
        int max = maki.get(0);
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (max < maki.get(i)) {
                max = maki.get(i);
            }
        }
        int divide = Collections.frequency(maki, max);
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (maki.get(i) == max) {
                scores.set(i, scores.get(i) + 6 / divide);
            }
        }
        if (divide == 1) {
            int max2 = maki.get(0);
            for (int i = 0; i < TOTAL_PLAYERS; i++) {
                if (maki.get(i) >= max2 && maki.get(i) != max) {
                    max2 = maki.get(i);
                }
            }
            for (int i = 0; i < TOTAL_PLAYERS; i++) {
                if (maki.get(i) == max2) {
                    scores.set(i, scores.get(i) + 3 / Collections.frequency(maki, max2));
                }
            }
        }
        //check for wasabi combos
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            while (tables.get(i).contains(CardType.Wasabi)) {
                int wasabiLocation = tables.get(i).indexOf(CardType.Wasabi);
                List<CardType> checkAfter = tables.get(i).subList(wasabiLocation, tables.get(i).size());
                for (int index = 0; index < checkAfter.size(); index++) {
                    if (checkAfter.get(index) == CardType.SquidNigiri) {
                        tables.get(i).remove(wasabiLocation + index);
                        scores.set(i, scores.get(i) + 9);
                        break;
                    } else if (checkAfter.get(index) == CardType.SalmonNigiri) {
                        tables.get(i).remove(wasabiLocation + index);
                        scores.set(i, scores.get(i) + 6);
                        break;
                    } else if (checkAfter.get(index) == CardType.EggNigiri) {
                        tables.get(i).remove(wasabiLocation + index);
                        scores.set(i, scores.get(i) + 3);
                        break;
                    }
                }
                tables.get(i).remove(CardType.Wasabi);
            }
        }
        //check for regular nigiri
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            scores.set(i, scores.get(i) + Collections.frequency(tables.get(i), CardType.SalmonNigiri) * 2);
        }
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            scores.set(i, scores.get(i) + Collections.frequency(tables.get(i), CardType.SquidNigiri) * 3);
        }
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            scores.set(i, scores.get(i) + Collections.frequency(tables.get(i), CardType.EggNigiri) * 1);
        }
        //check for dumpling combos
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            int dumplings = 0;
            while (tables.get(i).contains(CardType.Dumpling)) {
                dumplings++;
                tables.get(i).remove(CardType.Dumpling);
            }
            int dumpTotal = 0;
            if (dumplings == 1) {
                dumpTotal = 1;
            } else if (dumplings == 2) {
                dumpTotal = 3;
            } else if (dumplings == 3) {
                dumpTotal = 6;
            } else if (dumplings == 4) {
                dumpTotal = 10;
            } else if (dumplings > 4) {
                dumpTotal = 15;
            }
            scores.set(i, scores.get(i) + dumpTotal);
        }
        //check for tempura
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            int tempura = 0;
            while (tables.get(i).contains(CardType.Tempura)) {
                tempura = tempura + 1;
                tables.get(i).remove(CardType.Tempura);
            }
                scores.set(i, scores.get(i) + 5*(tempura/2));


        }
        //check for sashimi
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (Collections.frequency(tables.get(i), CardType.Sashimi) > 0) {
                scores.set(i, scores.get(i) + 10*(Collections.frequency(tables.get(i),CardType.Sashimi)/3));
            }
        }
        //add pudding to  pudding count
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            pudding_.set(i, pudding_.get(i) + Collections.frequency(tables.get(i), CardType.Pudding));
        }
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            scoreBoard.put(currentPlayers.get(i).getName(), scoreBoard.get(currentPlayers.get(i).getName()) + scores.get(i));
        }
        tables.get(0).clear();
        tables.get(1).clear();
        tables.get(2).clear();
        tables.get(3).clear();

    }

    public void endPudding() {
        int max = pudding_.get(0);
        int min = pudding_.get(0);
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (pudding_.get(i) > max) {
                max = pudding_.get(i);
            }
            if (pudding_.get(i) < min) {
                min = pudding_.get(i);
            }
        }
        int divideUp = Collections.frequency(pudding_, max);
        int divideDown = Collections.frequency(pudding_, max);
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (pudding_.get(i) == max) {
                scores.set(i, scores.get(i) + 6 / divideUp);
            }
            if (pudding_.get(i) == min) {
                scores.set(i, scores.get(i) + 6 / divideDown);
            }
        }
    }

    public void playGame() {
        startGame();
        for (int round = 1; round <= 3; round++) {
            currentHands.clear();
            drawHand();
            drawHand();
            drawHand();
            drawHand();
            currentPlayers.get(0).receiveHand(currentHands.get(0));
            currentPlayers.get(1).receiveHand(currentHands.get(1));
            currentPlayers.get(2).receiveHand(currentHands.get(2));
            currentPlayers.get(3).receiveHand(currentHands.get(3));
            for (int turn = 0; turn < 8; turn++) {
                ArrayList<TurnResult> allMovesMade = new ArrayList<TurnResult>();
                for (int i = 0; i < TOTAL_PLAYERS; i++) {
                    ArrayList<List<CardType>> cardsPlayed = new ArrayList<List<CardType>>();
                    boolean isValid = false;
                    while (!isValid) {
                        cardsPlayed.add(currentPlayers.get(i).giveCardsPlayed());
                        if (!tables.get(i).contains(CardType.Chopsticks)) {
                            List<CardType> hands = cardsPlayed.get(cardsPlayed.size() - 1);
                            if (hands.size() == 2) {
                                if (round % 2 == 0) {
                                    currentHands.get((i + 3 * turn) % TOTAL_PLAYERS).add(cardsPlayed.get(cardsPlayed.size() - 1).get(0));
                                    currentHands.get((i + 3 * turn) % TOTAL_PLAYERS).add(cardsPlayed.get(cardsPlayed.size() - 1).get(1));
                                    cardsPlayed.remove(cardsPlayed.size() - 1);
                                    continue;
                                } else {
                                    currentHands.get((i + turn) % TOTAL_PLAYERS).add(cardsPlayed.get(cardsPlayed.size() - 1).get(0));
                                    currentHands.get((i + turn) % TOTAL_PLAYERS).add(cardsPlayed.get(cardsPlayed.size() - 1).get(1));
                                    cardsPlayed.remove(cardsPlayed.size() - 1);
                                    continue;
                                }
                            }
                        }
                        isValid = true;
                    }
                    List<CardType> currentPlace = cardsPlayed.get(cardsPlayed.size() - 1);
                    for (int placeDown = 0; placeDown < currentPlace.size(); placeDown++) {
                        tables.get(i).add(cardsPlayed.get(0).get(placeDown));
                        if (placeDown == 1) {
                            tables.get(i).remove(CardType.Chopsticks);
                        }
                        TurnResult turnResult = new TurnResult(currentPlayers.get(i).getName(), cardsPlayed.get(0), tables.get(i));
                        allMovesMade.add(turnResult);
                    }
                }
                for (int i = 0; i < TOTAL_PLAYERS; i++) {
                    currentPlayers.get(i).receiveTurnResults(allMovesMade);
                }
                //fix to remove based on what hand was had
                passHand(round, turn);
            }
            calculateScore();
            currentPlayers.get(0).endRound(scoreBoard);
            currentPlayers.get(1).endRound(scoreBoard);
            currentPlayers.get(2).endRound(scoreBoard);
            currentPlayers.get(3).endRound(scoreBoard);
        }
        endPudding();
        currentPlayers.get(0).endGame(scoreBoard);
        currentPlayers.get(1).endGame(scoreBoard);
        currentPlayers.get(2).endGame(scoreBoard);
        currentPlayers.get(3).endGame(scoreBoard);
        int Winner = Collections.max(scores);
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (scores.get(i) == Winner) {
                if (Collections.frequency(scores, Winner) > 1) {
                    int puddingWin = pudding_.get(i);
                    for (int j = 0; j < TOTAL_PLAYERS; j++) {
                        if (puddingWin < pudding_.get(j) || scores.get(j) == Winner) {
                            puddingWin = pudding_.get(j);
                        }
                    }
                    if (puddingWin == pudding_.get(i)) {
                       // System.out.print("Congratulations " + currentPlayers.get(i).getName() + "\n ");
                        winner.set(i, winner.get(i) + 1);
                    }

                } else {
                    //System.out.print("Congratulations " + currentPlayers.get(i).getName() + "\n ");
                    winner.set(i, winner.get(i) + 1);
                }
            }
        }

    }

}
