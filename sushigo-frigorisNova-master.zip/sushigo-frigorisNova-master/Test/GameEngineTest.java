package com.example;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
//I'm sorry Alex IDK how to test outside of 100 random plays =C
//Technically by the weak law of large numbebrs if I run this 9001 times and no bugs pop up then we good/this is a joke in case you can't tell

public class GameEngineTest {
    @Test
    public void drawHand() throws Exception{

    }
    @Test
    public void testSameName() throws Exception{

    }
    @Test
    public void testChopsticks() throws Exception{

    }
    @Test
    public void testScore() throws Exception{

    }
    @Test
    public void testWasabi() throws Exception{

    }
    @Test
    public void testTempura() throws Exception{

    }
    @Test
    public void testMaki() throws Exception{

    }
    @Test
    public void testDumping() throws Exception{

    }
    @Test
    public void PuddingPersist throws Exception{

    }
    @Test
    public void noTieWinner() {

    }
    @Test
    public void puddingWinner() throws Exception{

    }

}